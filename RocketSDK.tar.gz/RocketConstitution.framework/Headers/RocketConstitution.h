//
//  RocketConstitution.h
//  RocketConstitution
//
//  Created by Alexey Khokhlov on 07.02.17.
//  Copyright © 2017 Alexey Khokhlov. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for RocketConstitution.
FOUNDATION_EXPORT double RocketConstitutionVersionNumber;

//! Project version string for RocketConstitution.
FOUNDATION_EXPORT const unsigned char RocketConstitutionVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <RocketConstitution/PublicHeader.h>


